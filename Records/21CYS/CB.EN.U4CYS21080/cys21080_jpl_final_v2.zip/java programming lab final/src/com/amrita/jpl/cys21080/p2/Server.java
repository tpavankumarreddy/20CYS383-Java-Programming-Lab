package com.amrita.jpl.cys21080.p2;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * The Server class handles the communication between the server and client in the Quiz Game.
 * @author T Pavan Kumar Reddy
 */
public class Server {
    /**
     * The main method is the entry point of the server application.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        try {
            ServerSocket ss = new ServerSocket(2444);
            System.out.println("Server started. Waiting for client connection...");

            Socket clientSocket = ss.accept();
            System.out.println("Client connected.");

            DataInputStream in = new DataInputStream(clientSocket.getInputStream());
            DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());

            QuizGameClient client = new QuizGameClient();

            client.startGame();

            String userInput;
            while ((userInput = in.readUTF()) != null) {
                // Pass the user's answer to the game client
                client.evaluateAnswer(userInput);
            }

            clientSocket.close();
            in.close();
            out.close();
            ss.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
