package com.amrita.jpl.cys21080.p2;

import java.util.Scanner;
/**
 * @author T Pavan kumar Reddy
 */

/**
 * Abstract class representing a Quiz Game.
 */
abstract class QuizGame {
    /**
     * Abstract method to ask a question.
     */
    abstract void askQuestion();

    /**
     * Abstract method to evaluate an answer.
     *
     * @param answer The answer to evaluate.
     */
    abstract void evaluateAnswer(String answer);

    /**
     * Starts the quiz game.
     */
    public void startGame() {
        System.out.println("Starting the Quiz Game!");
        askQuestion();
    }
}

/**
 * Interface for the Quiz Game listener.
 */
interface QuizGameListener {
    /**
     * Called when a question is asked.
     *
     * @param question The question asked.
     */
    void onQuestionAsked(String question);

    /**
     * Called when an answer is evaluated.
     *
     * @param isCorrect Indicates if the answer is correct.
     */
    void onAnswerEvaluated(boolean isCorrect);
}

/**
 * Server class for the Quiz Game.
 */
class QuizGameServer extends QuizGame {
    private final String questions[] = {
            "What is your name?",
            "What is the port number?"
    };

    private final String answers[] = {
            "Client", "2444"
    };

    private QuizGameListener listener;
    private int currentQuestionIndex;

    /**
     * Constructs a QuizGameServer object with the given listener.
     *
     * @param listener The QuizGameListener to notify.
     */
    public QuizGameServer(QuizGameListener listener) {
        this.listener = listener;
        currentQuestionIndex = 0;
    }

    @Override
    public void askQuestion() {
        String question = questions[currentQuestionIndex];
        notifyQuestionAsked(question);
    }

    @Override
    public void evaluateAnswer(String answer) {
        String correctAnswer = answers[currentQuestionIndex];
        boolean isCorrect = answer.equalsIgnoreCase(correctAnswer);
        notifyAnswerEvaluated(isCorrect);

        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            askQuestion();
        } else {
            // Game over
            declareWinner();
        }
    }

    private void notifyQuestionAsked(String question) {
        listener.onQuestionAsked(question);
    }

    private void notifyAnswerEvaluated(boolean isCorrect) {
        listener.onAnswerEvaluated(isCorrect);
    }

    private void declareWinner() {
        System.out.println("The winner is Client ");
    }
}

/**
 * Client class for the Quiz Game.
 */
class QuizGameClient implements QuizGameListener {
    private QuizGameServer server;
    private String currentQuestion;
    private boolean isAnswerCorrect;

    /**
     * Constructs a QuizGameClient object.
     */
    public QuizGameClient() {
        server = new QuizGameServer(this);
        currentQuestion = null;
        isAnswerCorrect = false;
    }

    /**
     * Starts the quiz game.
     */
    public void startGame() {
        server.startGame();
    }

    @Override
    public void onQuestionAsked(String question) {
        currentQuestion = question;
        askQuestion();
    }

    @Override
    public void onAnswerEvaluated(boolean isCorrect) {
        isAnswerCorrect = isCorrect;
        System.out.println("Answer is " + (isCorrect ? "correct!" : "incorrect!"));
    }

    private void askQuestion() {
        System.out.println("Question: " + currentQuestion);
        Scanner input = new Scanner(System.in);
        String userInput = input.nextLine();

        evaluateAnswer(userInput);
    }

    /**
     * Evaluates the answer.
     *
     * @param answer The answer to evaluate.
     */
    void evaluateAnswer(String answer) {
        server.evaluateAnswer(answer);
    }
}

/**
 * Main class representing the entry point of the program.
 */
public class Main {
    /**
     * The main method of the program.
     *
     * @param args The command-line arguments.
     */
    public static void main(String[] args) {
        QuizGameClient client = new QuizGameClient();
        client.startGame();
    }
}
