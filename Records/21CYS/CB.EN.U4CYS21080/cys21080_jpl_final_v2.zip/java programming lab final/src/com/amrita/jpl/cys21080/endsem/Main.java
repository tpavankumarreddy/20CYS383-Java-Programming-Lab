package com.amrita.jpl.cys21080.endsem;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;

/**
 * @author T Pavan Kumar Reddy
 * @version 1.0
 */
abstract class MyFile {
    private String fileName;
    private long fileSize;

    /**
     * Creates a new file with the given name and size.
     *
     * @param fileName the name of the file
     * @param fileSize the size of the file in bytes
     */
    public MyFile(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    /**
     * Retrieves the name of the file.
     *
     * @return the name of the file
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Retrieves the size of the file.
     *
     * @return the size of the file in bytes
     */
    public long getFileSize() {
        return fileSize;
    }

    /**
     * Displays the details of the file.
     */
    public abstract void displayFileDetails();
}

/**
 * Class representing a document file.
 */
class Document extends MyFile {
    private String documentType;

    /**
     * Creates a new document file with the given name, size, and type.
     *
     * @param fileName     the name of the document file
     * @param fileSize     the size of the document file in bytes
     * @param documentType the type of the document file
     */
    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    /**
     * Retrieves the type of the document file.
     *
     * @return the type of the document file
     */
    public String getDocumentType() {
        return documentType;
    }

    /**
     * Sets the type of the document file.
     *
     * @param documentType the type of the document file
     */
    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    /**
     * Displays the details of the document file.
     */
    public void displayFileDetails() {
        System.out.println("Document Name: " + getFileName());
        System.out.println("Document Size: " + getFileSize());
        System.out.println("Document Type: " + documentType);
        System.out.println();
    }
}

/**
 * Class representing an image file.
 */
class Image extends MyFile {
    private String resolution;

    /**
     * Creates a new image file with the given name, size, and resolution.
     *
     * @param fileName   the name of the image file
     * @param fileSize   the size of the image file in bytes
     * @param resolution the resolution of the image file
     */
    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    /**
     * Retrieves the resolution of the image file.
     *
     * @return the resolution of the image file
     */
    public String getResolution() {
        return resolution;
    }

    /**
     * Sets the resolution of the image file.
     *
     * @param resolution the resolution of the image file
     */
    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    /**
     * Displays the details of the image file.
     */
    public void displayFileDetails() {
        System.out.println("Image Name: " + getFileName());
        System.out.println("Image Size: " + getFileSize());
        System.out.println("Resolution: " + resolution);
        System.out.println();
    }
}

/**
 * Class representing a video file.
 */
class Video extends MyFile {
    private int duration;

    /**
     * Creates a new video file with the given name, size, and duration.
     *
     * @param fileName  the name of the video file
     * @param fileSize  the size of the video file in bytes
     * @param duration  the duration of the video file in seconds
     */
    public Video(String fileName, long fileSize, int duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    /**
     * Retrieves the duration of the video file.
     *
     * @return the duration of the video file in seconds
     */
    public int getDuration() {
        return duration;
    }

    /**
     * Sets the duration of the video file.
     *
     * @param duration the duration of the video file in seconds
     */
    public void setDuration(int duration) {
        this.duration = duration;
    }

    /**
     * Displays the details of the video file.
     */
    public void displayFileDetails() {
        System.out.println("Video Name: " + getFileName());
        System.out.println("Video Size: " + getFileSize());
        System.out.println("Duration: " + duration + " seconds");
        System.out.println();
    }
}

/**
 * Interface representing a file manager.
 */
interface FileManager {
    /**
     * Adds a file to the file manager.
     *
     * @param file the file to be added
     */
    void addFile(MyFile file);

    /**
     * Deletes a file from the file manager based on the file name.
     *
     * @param fileName the name of the file to be deleted
     */
    void deleteFile(String fileName);

    /**
     * Saves the files to a file.
     */
    void saveToFile();

    /**
     * Loads the files from a file.
     */
    void loadFromFile();

    /**
     * Retrieves the list of files in the file manager.
     *
     * @return the list of files
     */
    ArrayList<MyFile> getFiles();
}

/**
 * Class implementing the FileManager interface.
 */
class FileManagerImpl implements FileManager {
    private ArrayList<MyFile> files;

    /**
     * Creates a new FileManagerImpl instance.
     */
    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    public void addFile(MyFile file) {
        files.add(file);
    }

    public void deleteFile(String fileName) {
        for (int i = 0; i < files.size(); i++) {
            MyFile file = files.get(i);
            if (file.getFileName().equals(fileName)) {
                files.remove(i);
                break;
            }
        }
    }

    public void saveToFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try (PrintWriter writer = new PrintWriter(new FileWriter(selectedFile.getAbsolutePath()))) {
                for (MyFile file : files) {
                    writer.println(file.getClass().getSimpleName());
                    writer.println(file.getFileName());
                    writer.println(file.getFileSize());
                    if (file instanceof Document) {
                        writer.println(((Document) file).getDocumentType());
                    } else if (file instanceof Image) {
                        writer.println(((Image) file).getResolution());
                    } else if (file instanceof Video) {
                        writer.println(((Video) file).getDuration());
                    }
                    writer.println();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void loadFromFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try (BufferedReader reader = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()))) {
                files.clear();
                String line;
                while ((line = reader.readLine()) != null) {
                    String fileType = line;
                    String fileName = reader.readLine();
                    long fileSize = Long.parseLong(reader.readLine());
                    if (fileType.equals("Document")) {
                        String documentType = reader.readLine();
                        Document document = new Document(fileName, fileSize, documentType);
                        files.add(document);
                    } else if (fileType.equals("Image")) {
                        String resolution = reader.readLine();
                        Image image = new Image(fileName, fileSize, resolution);
                        files.add(image);
                    } else if (fileType.equals("Video")) {
                        int duration = Integer.parseInt(reader.readLine());
                        Video video = new Video(fileName, fileSize, duration);
                        files.add(video);
                    }
                    reader.readLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public ArrayList<MyFile> getFiles() {
        return files;
    }
}

/**
 * Class representing the user interface for the file management system.
 */
class FileManagementSystemUI {
    private JFrame frame;
    private JTextField fileNameTextField;
    private JTextField fileSizeTextField;
    private JComboBox<String> fileTypeComboBox;
    private JButton addFileButton;
    private DefaultTableModel tableModel;
    private JTable fileTable;
    private FileManager fileManager;
    private JButton deleteFileButton;

    /**
     * Creates a new FileManagementSystemUI instance.
     */
    public FileManagementSystemUI() {
        fileManager = new FileManagerImpl();
        createUI();
        createTableModel();
    }

    private void createTableModel() {
        tableModel = new DefaultTableModel(new Object[]{"File Type", "File Name", "File Size"}, 0);
        JTable fileTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(fileTable);
        frame.add(scrollPane, BorderLayout.CENTER);
    }

    private void createUI() {
        frame = new JFrame("21UCYS End Semester Assignment File Manager");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new Object[]{"File Name", "File Size", "File Type"}, 0);
        JTable contactTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(contactTable);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(1, 6));

        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel fileNameLabel = new JLabel("File Name:");
        JLabel fileSizeLabel = new JLabel("File Size:");
        JLabel fileTypeLabel = new JLabel("File Type:");

        fileNameTextField = new JTextField();
        fileSizeTextField = new JTextField();
        String[] fileTypes = {"Document", "Image", "Video"};
        fileTypeComboBox = new JComboBox<>(fileTypes);

        inputPanel.add(fileNameLabel);
        inputPanel.add(fileNameTextField);
        inputPanel.add(fileSizeLabel);
        inputPanel.add(fileSizeTextField);
        inputPanel.add(fileTypeLabel);
        inputPanel.add(fileTypeComboBox);

        frame.add(inputPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel();
        fileTable = new JTable(tableModel);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());

        addFileButton = new JButton("Add File");
        JButton refreshButton = new JButton("Refresh");
        deleteFileButton = new JButton("Delete File");

        buttonPanel.add(addFileButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(deleteFileButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        frame.setSize(600, 400);
        frame.setVisible(true);

        addFileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String fileName = fileNameTextField.getText();
                long fileSize = Long.parseLong(fileSizeTextField.getText());
                String fileType = (String) fileTypeComboBox.getSelectedItem();

                MyFile file;
                if (fileType.equals("Document")) {
                    String documentType = JOptionPane.showInputDialog(frame, "Enter Document Type:");
                    file = new Document(fileName, fileSize, documentType);
                } else if (fileType.equals("Image")) {
                    String resolution = JOptionPane.showInputDialog(frame, "Enter Resolution:");
                    file = new Image(fileName, fileSize, resolution);
                } else {
                    int duration = Integer.parseInt(JOptionPane.showInputDialog(frame, "Enter Duration (seconds):"));
                    file = new Video(fileName, fileSize, duration);
                }

                fileManager.addFile(file);
                refreshFileTable();
                clearInputFields();
            }
        });

        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refreshFileTable();
            }
        });

        deleteFileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = fileTable.getSelectedRow();
                if (selectedRow != -1) {
                    String fileName = (String) fileTable.getValueAt(selectedRow, 0);
                    fileManager.deleteFile(fileName);
                    refreshFileTable();
                }
            }
        });
    }

    private void refreshFileTable() {
        tableModel.setRowCount(0);
        ArrayList<MyFile> files = fileManager.getFiles();
        for (MyFile file : files) {
            String fileType = file.getClass().getSimpleName();
            String fileName = file.getFileName();
            long fileSize = file.getFileSize();
            tableModel.addRow(new Object[]{fileType, fileName, fileSize});
        }
    }

    private void clearInputFields() {
        fileNameTextField.setText("");
        fileSizeTextField.setText("");
        fileTypeComboBox.setSelectedIndex(0);
    }
}

public class Main {
    public static void main(String[] args) {
        FileManagementSystemUI fileManagementSystemUI = new FileManagementSystemUI();
    }
}
