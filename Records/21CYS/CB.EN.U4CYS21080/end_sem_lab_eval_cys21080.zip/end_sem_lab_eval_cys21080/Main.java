package com.amrita.jpl21cys80.endsem;

/**
 * @author T Pavan Kumar Reddy
 * @version 1.0
 */

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;


abstract class MyFile {
    private String fileName;
    private long fileSize;

    public MyFile(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    public abstract void displayFileDetails();
}

class Document extends MyFile {
    private String documentType;

    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public void displayFileDetails() {
        System.out.println("Document Name: " + getFileName());
        System.out.println("Document Size: " + getFileSize());
        System.out.println("Document Type: " + documentType);
        System.out.println();
    }
}

class Image extends MyFile {
    private String resolution;

    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public void displayFileDetails() {
        System.out.println("Image Name: " + getFileName());
        System.out.println("Image Size: " + getFileSize());
        System.out.println("Resolution: " + resolution);
        System.out.println();
    }
}

class Video extends MyFile {
    private int duration;

    public Video(String fileName, long fileSize, int duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void displayFileDetails() {
        System.out.println("Video Name: " + getFileName());
        System.out.println("Video Size: " + getFileSize());
        System.out.println("Duration: " + duration + " seconds");
        System.out.println();
    }
}

interface FileManager {
    void addFile(MyFile file);

    void deleteFile(String fileName);

    void saveToFile();

    void loadFromFile();

    ArrayList<MyFile> getFiles();
}

class FileManagerImpl implements FileManager {
    private ArrayList<MyFile> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    public void addFile(MyFile file) {
        files.add(file);
    }

    public void deleteFile(String fileName) {
        for (int i = 0; i < files.size(); i++) {
            MyFile file = files.get(i);
            if (file.getFileName().equals(fileName)) {
                files.remove(i);
                break;
            }
        }
    }

    public void saveToFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try (PrintWriter writer = new PrintWriter(new FileWriter(selectedFile.getAbsolutePath()))) {
                for (MyFile file : files) {
                    writer.println(file.getClass().getSimpleName());
                    writer.println(file.getFileName());
                    writer.println(file.getFileSize());
                    if (file instanceof Document) {
                        writer.println(((Document) file).getDocumentType());
                    } else if (file instanceof Image) {
                        writer.println(((Image) file).getResolution());
                    } else if (file instanceof Video) {
                        writer.println(((Video) file).getDuration());
                    }
                    writer.println();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void loadFromFile() {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            try (BufferedReader reader = new BufferedReader(new FileReader(selectedFile.getAbsolutePath()))) {
                files.clear();
                String line;
                while ((line = reader.readLine()) != null) {
                    String fileType = line;
                    String fileName = reader.readLine();
                    long fileSize = Long.parseLong(reader.readLine());
                    if (fileType.equals("Document")) {
                        String documentType = reader.readLine();
                        Document document = new Document(fileName, fileSize, documentType);
                        files.add(document);
                    } else if (fileType.equals("Image")) {
                        String resolution = reader.readLine();
                        Image image = new Image(fileName, fileSize, resolution);
                        files.add(image);
                    } else if (fileType.equals("Video")) {
                        int duration = Integer.parseInt(reader.readLine());
                        Video video = new Video(fileName, fileSize, duration);
                        files.add(video);
                    }
                    reader.readLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public ArrayList<MyFile> getFiles() {
        return files;
    }
}


class FileManagementSystemUI {
    private JFrame frame;
    private JTextField fileNameTextField;
    private JTextField fileSizeTextField;
    private JComboBox<String> fileTypeComboBox;
    private JButton addFileButton;
    private DefaultTableModel tableModel;
    private JTable fileTable;
    private JTable contactTable;
    private FileManager fileManager;
    private JButton deleteFileButton;

    public FileManagementSystemUI() {
        fileManager = new FileManagerImpl();
        createUI();
        createTableModel();
    }

    private void createTableModel() {
        tableModel = new DefaultTableModel(new Object[]{"File Type", "File Name", "File Size"}, 0);
        JTable fileTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(fileTable);
        frame.add(scrollPane, BorderLayout.CENTER);
    }

    private void createUI() {
        frame = new JFrame("21UCYS End Semester Assignment File Manager");

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        tableModel = new DefaultTableModel(new Object[]{"File Name", "File Size", "File Type"}, 0);
        contactTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(contactTable);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(1, 6));

        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel fileNameLabel = new JLabel("File Name:");
        JLabel fileSizeLabel = new JLabel("File Size:");
        JLabel fileTypeLabel = new JLabel("File Type:");

        fileNameTextField = new JTextField();
        fileSizeTextField = new JTextField();
        String[] fileTypes = {"Document", "Image", "Video"};
        fileTypeComboBox = new JComboBox<>(fileTypes);

        inputPanel.add(fileNameLabel);
        inputPanel.add(fileNameTextField);
        inputPanel.add(fileSizeLabel);
        inputPanel.add(fileSizeTextField);
        inputPanel.add(fileTypeLabel);
        inputPanel.add(fileTypeComboBox);

        frame.add(inputPanel, BorderLayout.NORTH);

        tableModel = new DefaultTableModel();
        fileTable = new JTable(tableModel);
        frame.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());

        addFileButton = new JButton("Add File");
        JButton refreshButton = new JButton("Refresh");
        deleteFileButton = new JButton("Delete File");



        buttonPanel.add(addFileButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(deleteFileButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);

        addFileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String fileName = fileNameTextField.getText();
                String fileSizeStr = fileSizeTextField.getText();
                String fileType = (String) fileTypeComboBox.getSelectedItem();

                if (fileType.equals("Document")) {
                    String documentType = JOptionPane.showInputDialog(frame, "Enter document type:");
                    long fileSize = Long.parseLong(fileSizeStr);
                    MyFile file = new Document(fileName, fileSize, documentType);
                    fileManager.addFile(file);
                } else if (fileType.equals("Image")) {
                    String resolution = JOptionPane.showInputDialog(frame, "Enter resolution:");
                    long fileSize = Long.parseLong(fileSizeStr);
                    MyFile file = new Image(fileName, fileSize, resolution);
                    fileManager.addFile(file);
                } else if (fileType.equals("Video")) {
                    String durationStr = JOptionPane.showInputDialog(frame, "Enter duration (in seconds):");
                    long fileSize = Long.parseLong(fileSizeStr);
                    int duration = Integer.parseInt(durationStr);
                    MyFile file = new Video(fileName, fileSize, duration);
                    fileManager.addFile(file);
                }

                refreshfileTable();
            }
        });


        refreshButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                refreshfileTable();
            }

        });

        deleteFileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = fileTable.getSelectedRow();
                if (selectedRow != -1) {
                    String fileName = (String) fileTable.getValueAt(selectedRow, 1);
                    fileManager.deleteFile(fileName);
                    refreshfileTable();
                } else {
                    JOptionPane.showMessageDialog(frame, "Please select a file to delete.");
                }
            }
        });

        frame.pack();
        frame.setVisible(true);
    }




    private void refreshfileTable() {
        tableModel.setRowCount(0);
        ArrayList<MyFile> files = fileManager.getFiles();
        for (MyFile file : files) {

            String fileName = file.getFileName();
            long fileSize = file.getFileSize();
            String fileType = file.getClass().getSimpleName();
            tableModel.addRow(new Object[]{fileName, fileSize,fileType});
        }
    }


}

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new FileManagementSystemUI();
            }
        });
    }
}

