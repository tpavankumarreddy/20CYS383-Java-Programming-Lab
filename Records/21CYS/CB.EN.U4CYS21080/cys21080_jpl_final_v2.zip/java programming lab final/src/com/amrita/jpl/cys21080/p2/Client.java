package com.amrita.jpl.cys21080.p2;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

/**
 * The Client class represents the client side of the Quiz Game.
 * @author T Pavan Kumar Reddy
 */
public class Client {
    /**
     * The main method is the entry point of the client application.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 2444);
            System.out.println("Connected to the server.");

            DataInputStream in = new DataInputStream(socket.getInputStream());
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());

            QuizGameClient client = new QuizGameClient();

            client.startGame();

            String serverMessage;
            while ((serverMessage = in.readUTF()) != null) {
                // Display the question from the server
                client.onQuestionAsked(serverMessage);

                Scanner input = new Scanner(System.in);
                String userInput = input.nextLine();
                out.writeUTF(userInput);
            }

            // Close the socket and streams
            socket.close();
            in.close();
            out.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
